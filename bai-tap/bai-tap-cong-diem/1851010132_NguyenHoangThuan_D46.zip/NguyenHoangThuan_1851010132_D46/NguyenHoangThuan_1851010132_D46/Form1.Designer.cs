﻿namespace NguyenHoangThuan_1851010132_D46
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelTieuDe = new System.Windows.Forms.Label();
            this.labelTenKhachHang = new System.Windows.Forms.Label();
            this.textBoxTenKhachHang = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.labelChiTietHoaDon = new System.Windows.Forms.Label();
            this.checkBoxCaoVoi = new System.Windows.Forms.CheckBox();
            this.checkBoxTayTrang = new System.Windows.Forms.CheckBox();
            this.checkBoxChupHinhRang = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelTramRang = new System.Windows.Forms.Label();
            this.numericUpDownSoRangTram = new System.Windows.Forms.NumericUpDown();
            this.labelTongTien = new System.Windows.Forms.Label();
            this.buttonThoat = new System.Windows.Forms.Button();
            this.buttonTinhTien = new System.Windows.Forms.Button();
            this.textBoxTongTien = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSoRangTram)).BeginInit();
            this.SuspendLayout();
            // 
            // labelTieuDe
            // 
            this.labelTieuDe.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelTieuDe.Font = new System.Drawing.Font("Miriam Transparent", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.labelTieuDe.ForeColor = System.Drawing.SystemColors.Desktop;
            this.labelTieuDe.Location = new System.Drawing.Point(0, 0);
            this.labelTieuDe.Name = "labelTieuDe";
            this.labelTieuDe.Size = new System.Drawing.Size(556, 23);
            this.labelTieuDe.TabIndex = 0;
            this.labelTieuDe.Text = "DENTAL PAYMENT FORM";
            this.labelTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTenKhachHang
            // 
            this.labelTenKhachHang.AutoSize = true;
            this.labelTenKhachHang.Location = new System.Drawing.Point(12, 46);
            this.labelTenKhachHang.Name = "labelTenKhachHang";
            this.labelTenKhachHang.Size = new System.Drawing.Size(86, 13);
            this.labelTenKhachHang.TabIndex = 1;
            this.labelTenKhachHang.Text = "Tên khách hàng";
            // 
            // textBoxTenKhachHang
            // 
            this.textBoxTenKhachHang.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBoxTenKhachHang.Location = new System.Drawing.Point(121, 46);
            this.textBoxTenKhachHang.Name = "textBoxTenKhachHang";
            this.textBoxTenKhachHang.Size = new System.Drawing.Size(100, 20);
            this.textBoxTenKhachHang.TabIndex = 2;
            this.textBoxTenKhachHang.TextChanged += new System.EventHandler(this.textBoxTenKhachHang_TextChanged);
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(304, 69);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(240, 262);
            this.listBox1.TabIndex = 3;
            // 
            // labelChiTietHoaDon
            // 
            this.labelChiTietHoaDon.AutoSize = true;
            this.labelChiTietHoaDon.Location = new System.Drawing.Point(301, 46);
            this.labelChiTietHoaDon.Name = "labelChiTietHoaDon";
            this.labelChiTietHoaDon.Size = new System.Drawing.Size(82, 13);
            this.labelChiTietHoaDon.TabIndex = 4;
            this.labelChiTietHoaDon.Text = "Chi tiết hóa đơn";
            // 
            // checkBoxCaoVoi
            // 
            this.checkBoxCaoVoi.AutoSize = true;
            this.checkBoxCaoVoi.Location = new System.Drawing.Point(15, 103);
            this.checkBoxCaoVoi.Name = "checkBoxCaoVoi";
            this.checkBoxCaoVoi.Size = new System.Drawing.Size(63, 17);
            this.checkBoxCaoVoi.TabIndex = 5;
            this.checkBoxCaoVoi.Text = "Cạo Vôi";
            this.checkBoxCaoVoi.UseVisualStyleBackColor = true;
            // 
            // checkBoxTayTrang
            // 
            this.checkBoxTayTrang.AutoSize = true;
            this.checkBoxTayTrang.Location = new System.Drawing.Point(15, 146);
            this.checkBoxTayTrang.Name = "checkBoxTayTrang";
            this.checkBoxTayTrang.Size = new System.Drawing.Size(71, 17);
            this.checkBoxTayTrang.TabIndex = 6;
            this.checkBoxTayTrang.Text = "Tẩy trắng";
            this.checkBoxTayTrang.UseVisualStyleBackColor = true;
            // 
            // checkBoxChupHinhRang
            // 
            this.checkBoxChupHinhRang.AutoSize = true;
            this.checkBoxChupHinhRang.Location = new System.Drawing.Point(15, 188);
            this.checkBoxChupHinhRang.Name = "checkBoxChupHinhRang";
            this.checkBoxChupHinhRang.Size = new System.Drawing.Size(98, 17);
            this.checkBoxChupHinhRang.TabIndex = 7;
            this.checkBoxChupHinhRang.Text = "Chụp hình răng";
            this.checkBoxChupHinhRang.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(175, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 19);
            this.label1.TabIndex = 8;
            this.label1.Text = "100.000 vnđ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(175, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 19);
            this.label2.TabIndex = 9;
            this.label2.Text = "1.200.000 vnđ";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(175, 186);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 19);
            this.label3.TabIndex = 10;
            this.label3.Text = "200.000 vnđ";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(175, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 19);
            this.label4.TabIndex = 11;
            this.label4.Text = "80.000 vnđ/cái";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // labelTramRang
            // 
            this.labelTramRang.AutoSize = true;
            this.labelTramRang.Location = new System.Drawing.Point(12, 227);
            this.labelTramRang.Name = "labelTramRang";
            this.labelTramRang.Size = new System.Drawing.Size(55, 13);
            this.labelTramRang.TabIndex = 13;
            this.labelTramRang.Text = "Trám răng";
            // 
            // numericUpDownSoRangTram
            // 
            this.numericUpDownSoRangTram.Location = new System.Drawing.Point(89, 225);
            this.numericUpDownSoRangTram.Name = "numericUpDownSoRangTram";
            this.numericUpDownSoRangTram.Size = new System.Drawing.Size(61, 20);
            this.numericUpDownSoRangTram.TabIndex = 14;
            // 
            // labelTongTien
            // 
            this.labelTongTien.AutoSize = true;
            this.labelTongTien.Location = new System.Drawing.Point(12, 279);
            this.labelTongTien.Name = "labelTongTien";
            this.labelTongTien.Size = new System.Drawing.Size(52, 13);
            this.labelTongTien.TabIndex = 15;
            this.labelTongTien.Text = "Tổng tiền";
            // 
            // buttonThoat
            // 
            this.buttonThoat.Enabled = false;
            this.buttonThoat.Location = new System.Drawing.Point(15, 317);
            this.buttonThoat.Name = "buttonThoat";
            this.buttonThoat.Size = new System.Drawing.Size(90, 33);
            this.buttonThoat.TabIndex = 16;
            this.buttonThoat.Text = "Thoát";
            this.buttonThoat.UseVisualStyleBackColor = true;
            this.buttonThoat.Click += new System.EventHandler(this.buttonThoat_Click);
            // 
            // buttonTinhTien
            // 
            this.buttonTinhTien.Enabled = false;
            this.buttonTinhTien.Location = new System.Drawing.Point(194, 317);
            this.buttonTinhTien.Name = "buttonTinhTien";
            this.buttonTinhTien.Size = new System.Drawing.Size(90, 33);
            this.buttonTinhTien.TabIndex = 17;
            this.buttonTinhTien.Text = "Tính tiền";
            this.buttonTinhTien.UseVisualStyleBackColor = true;
            this.buttonTinhTien.Click += new System.EventHandler(this.buttonTinhTien_Click);
            // 
            // textBoxTongTien
            // 
            this.textBoxTongTien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTongTien.Location = new System.Drawing.Point(89, 279);
            this.textBoxTongTien.Name = "textBoxTongTien";
            this.textBoxTongTien.Size = new System.Drawing.Size(195, 13);
            this.textBoxTongTien.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 366);
            this.Controls.Add(this.textBoxTongTien);
            this.Controls.Add(this.buttonTinhTien);
            this.Controls.Add(this.buttonThoat);
            this.Controls.Add(this.labelTongTien);
            this.Controls.Add(this.numericUpDownSoRangTram);
            this.Controls.Add(this.labelTramRang);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBoxChupHinhRang);
            this.Controls.Add(this.checkBoxTayTrang);
            this.Controls.Add(this.checkBoxCaoVoi);
            this.Controls.Add(this.labelChiTietHoaDon);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBoxTenKhachHang);
            this.Controls.Add(this.labelTenKhachHang);
            this.Controls.Add(this.labelTieuDe);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSoRangTram)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelTieuDe;
        private System.Windows.Forms.Label labelTenKhachHang;
        private System.Windows.Forms.TextBox textBoxTenKhachHang;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label labelChiTietHoaDon;
        private System.Windows.Forms.CheckBox checkBoxCaoVoi;
        private System.Windows.Forms.CheckBox checkBoxTayTrang;
        private System.Windows.Forms.CheckBox checkBoxChupHinhRang;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelTramRang;
        private System.Windows.Forms.NumericUpDown numericUpDownSoRangTram;
        private System.Windows.Forms.Label labelTongTien;
        private System.Windows.Forms.Button buttonThoat;
        private System.Windows.Forms.Button buttonTinhTien;
        private System.Windows.Forms.TextBox textBoxTongTien;
    }
}

