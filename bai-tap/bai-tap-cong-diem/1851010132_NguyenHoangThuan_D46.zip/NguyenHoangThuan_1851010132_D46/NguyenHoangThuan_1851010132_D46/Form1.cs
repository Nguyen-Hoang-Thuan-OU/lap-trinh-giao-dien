﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace NguyenHoangThuan_1851010132_D46
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (textBoxTenKhachHang.Text == "")
            {
                buttonThoat.Enabled = false;
                buttonTinhTien.Enabled = false;
            }
        }

        private void buttonTinhTien_Click(object sender, EventArgs e)
        {
            int caoVoi, tayTrang, chupHinhRang, tramRang;
            double tongTien = 0;

            caoVoi = 100000;
            tayTrang = 1200000;
            chupHinhRang = 200000;
            tramRang = 80000;

            if (checkBoxCaoVoi.Checked)
                tongTien = tongTien + caoVoi;
            if (checkBoxTayTrang.Checked)
                tongTien = tongTien + tayTrang;
            if (checkBoxChupHinhRang.Checked)
                tongTien = tongTien + chupHinhRang;

            textBoxTongTien.Text = String.Format("{0:0.00}", tongTien);
        }

        private void buttonThoat_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Bạn có muốn thoát hay không?", "BẠN ĐANG THOÁT!?", MessageBoxButtons.YesNo) == DialogResult.No)
                e.Cancel = true;
        }

        private void textBoxTenKhachHang_TextChanged(object sender, EventArgs e)
        {
            buttonThoat.Enabled = true;
            buttonTinhTien.Enabled = true;
        }
    }
}
